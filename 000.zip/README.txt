=======================
===PRANK ALERT!=====
=======================

This is NOT a real virus.

The file "000.bat" is just a harmless prank created for fun.
It opens some programs, displays fake errors, and loops to be annoying.

✅ It does NOT delete any files.
✅ It does NOT steal data.
✅ It does NOT harm your system.

To stop it, just close the command prompt windows or use Task Manager (Ctrl+Shift+Esc).

Next time, don't run suspicious files 😉
- From your friendly prankster